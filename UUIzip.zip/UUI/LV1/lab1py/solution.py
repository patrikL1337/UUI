
import argparse
import heapq
from collections import deque

# 1. UCITAVANJE PROSTORA STANJA

def ucitaj_prostor_stanja(putanja):
    linije = []

    with open(putanja, "r", encoding="utf-8") as datoteka:
        for linija in datoteka:
            linija = linija.strip()

            if linija and not linija.startswith("#"):
                linije.append(linija)

    pocetno_stanje = linije[0]
    ciljna_stanja = set(linije[1].split())

    graf = {}

    for linija in linije[2:]:
        stanje, prijelazi = linija.split(":", 1)
        stanje = stanje.strip()

        susjedi = []

        for prijelaz in prijelazi.split():
            susjed, cijena = prijelaz.split(",")
            susjedi.append((susjed, float(cijena)))

        graf[stanje] = sorted(susjedi, key=lambda x: x[0])

    return pocetno_stanje, ciljna_stanja, graf

# 2. UCITAVANJE HEURISTIKE

def ucitaj_heuristiku(putanja):
    heuristika = {}

    with open(putanja, "r", encoding="utf-8") as datoteka:
        for linija in datoteka:
            linija = linija.strip()

            if not linija or linija.startswith("#"):
                continue

            stanje, vrijednost = linija.split(":", 1)
            heuristika[stanje.strip()] = float(vrijednost)

    return heuristika

# 3. BFS ALGORITAM

def bfs(pocetak, ciljevi, graf):
    red = deque()
    red.append((pocetak, [pocetak], 0.0))

    otkriveni = {pocetak}
    closed = set()

    while red:
        stanje, put, cijena = red.popleft()

        if stanje in closed:
            continue

        closed.add(stanje)

        if stanje in ciljevi:
            return True, len(closed), put, cijena

        for susjed, cijena_prijelaza in graf.get(stanje, []):
            if susjed not in otkriveni:
                otkriveni.add(susjed)

                red.append((
                    susjed,
                    put + [susjed],
                    cijena + cijena_prijelaza
                ))

    return False, len(closed), [], 0.0

# 4. UCS ALGORITAM

def ucs(pocetak, ciljevi, graf):
    red = [(0.0, pocetak, [pocetak])]
    najbolje_cijene = {pocetak: 0.0}
    closed = set()

    while red:
        cijena, stanje, put = heapq.heappop(red)

        if stanje in closed:
            continue

        if cijena > najbolje_cijene.get(stanje, float("inf")):
            continue

        closed.add(stanje)

        if stanje in ciljevi:
            return True, len(closed), put, cijena

        for susjed, cijena_prijelaza in graf.get(stanje, []):
            nova_cijena = cijena + cijena_prijelaza

            if (susjed not in closed and
                    nova_cijena < najbolje_cijene.get(
                        susjed, float("inf")
                    )):

                najbolje_cijene[susjed] = nova_cijena

                heapq.heappush(
                    red,
                    (nova_cijena, susjed, put + [susjed])
                )

    return False, len(closed), [], 0.0

# 5. A* ALGORITAM

def astar(pocetak, ciljevi, graf, heuristika):
    pocetni_h = heuristika[pocetak]

    red = [(pocetni_h, pocetak, 0.0, [pocetak])]
    najbolje_cijene = {pocetak: 0.0}
    closed = set()

    while red:
        f, stanje, g, put = heapq.heappop(red)

        if g > najbolje_cijene.get(stanje, float("inf")):
            continue

        if stanje in closed:
            continue

        closed.add(stanje)

        if stanje in ciljevi:
            return True, len(closed), put, g

        for susjed, cijena_prijelaza in graf.get(stanje, []):
            novi_g = g + cijena_prijelaza

            if novi_g < najbolje_cijene.get(
                susjed, float("inf")
            ):
                najbolje_cijene[susjed] = novi_g

                # Ponovno otvaranje stanja ako je pronaden
                # bolji put do njega.
                if susjed in closed:
                    closed.remove(susjed)

                novi_f = novi_g + heuristika[susjed]

                heapq.heappush(
                    red,
                    (novi_f, susjed, novi_g, put + [susjed])
                )

    return False, len(closed), [], 0.0

# 6. ISPIS REZULTATA PRETRAZIVANJA

def ispisi_rezultat(rezultat):
    pronadeno, posjeceno, put, cijena = rezultat

    if not pronadeno:
        print("[FOUND_SOLUTION]: no")
        return

    print("[FOUND_SOLUTION]: yes")
    print("[STATES_VISITED]:", posjeceno)
    print("[PATH_LENGTH]:", len(put))
    print("[TOTAL_COST]:", "{:.1f}".format(cijena))
    print("[PATH]:", " => ".join(put))

# 7. NAJKRACI PUT DO CILJA ZA PROVJERU HEURISTIKE

def stvarna_cijena_do_cilja(pocetak, ciljevi, graf):
    pronadeno, _, _, cijena = ucs(
        pocetak, ciljevi, graf
    )

    if pronadeno:
        return cijena

    return float("inf")

# 8. PROVJERA OPTIMISTICNOSTI

def provjeri_optimisticnost(graf, ciljevi, heuristika):
    optimisticna = True

    for stanje in sorted(heuristika):
        h = heuristika[stanje]

        h_star = stvarna_cijena_do_cilja(
            stanje, ciljevi, graf
        )

        uvjet = h <= h_star

        if not uvjet:
            optimisticna = False

        oznaka = "[OK]" if uvjet else "[ERR]"

        print(
            "[CONDITION]: {} h({}) <= h*: {:.1f} <= {:.1f}".format(
                oznaka, stanje, h, h_star
            )
        )

    if optimisticna:
        print("[CONCLUSION]: Heuristic is optimistic.")
    else:
        print("[CONCLUSION]: Heuristic is not optimistic.")

# 9. PROVJERA KONZISTENTNOSTI

def provjeri_konzistentnost(graf, heuristika):
    konzistentna = True

    for stanje in sorted(graf):
        h_stanje = heuristika[stanje]

        for susjed, cijena in graf[stanje]:
            h_susjed = heuristika[susjed]

            uvjet = h_stanje <= h_susjed + cijena

            if not uvjet:
                konzistentna = False

            oznaka = "[OK]" if uvjet else "[ERR]"

            print(
                "[CONDITION]: {} h({}) <= h({}) + c: "
                "{:.1f} <= {:.1f} + {:.1f}".format(
                    oznaka,
                    stanje,
                    susjed,
                    h_stanje,
                    h_susjed,
                    cijena
                )
            )

    if konzistentna:
        print("[CONCLUSION]: Heuristic is consistent.")
    else:
        print("[CONCLUSION]: Heuristic is not consistent.")

# 10. GLAVNI PROGRAM

def main():
    parser = argparse.ArgumentParser()

    parser.add_argument("--ss", type=str)
    parser.add_argument(
        "--alg",
        choices=["bfs", "ucs", "astar"]
    )
    parser.add_argument("--h", type=str)
    parser.add_argument(
        "--check-optimistic",
        action="store_true"
    )
    parser.add_argument(
        "--check-consistent",
        action="store_true"
    )

    args = parser.parse_args()

    if not args.ss:
        parser.error("Potrebno je navesti --ss")

    pocetak, ciljevi, graf = ucitaj_prostor_stanja(
        args.ss
    )

    if args.check_optimistic or args.check_consistent:
        if not args.h:
            parser.error("Potrebno je navesti --h")

        heuristika = ucitaj_heuristiku(args.h)

        if args.check_optimistic:
            print("# HEURISTIC-OPTIMISTIC", args.h)
            provjeri_optimisticnost(
                graf, ciljevi, heuristika
            )

        if args.check_consistent:
            print("# HEURISTIC-CONSISTENT", args.h)
            provjeri_konzistentnost(
                graf, heuristika
            )

    elif args.alg == "bfs":
        print("# BFS")
        rezultat = bfs(pocetak, ciljevi, graf)
        ispisi_rezultat(rezultat)

    elif args.alg == "ucs":
        print("# UCS")
        rezultat = ucs(pocetak, ciljevi, graf)
        ispisi_rezultat(rezultat)

    elif args.alg == "astar":
        if not args.h:
            parser.error("A* zahtijeva --h")

        heuristika = ucitaj_heuristiku(args.h)

        print("# A-STAR", args.h)

        rezultat = astar(
            pocetak, ciljevi, graf, heuristika
        )
        ispisi_rezultat(rezultat)

    else:
        parser.error("Potrebno je odabrati algoritam ili provjeru")

if __name__ == "__main__":
    main()
